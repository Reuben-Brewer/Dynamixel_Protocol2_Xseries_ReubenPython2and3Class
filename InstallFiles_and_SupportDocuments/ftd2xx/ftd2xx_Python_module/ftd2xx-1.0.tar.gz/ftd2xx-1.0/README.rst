======
FTD2XX
======

ftd2xx is a simple python wrapper around the `D2XX DLL`_ from FTDI using
ctypes. It is based on Pablo Bleyer Kocik's d2xx_ extension.


.. _d2xx: http://bleyer.org/pyusb/
.. _D2XX DLL: http://www.ftdichip.com/Drivers/D2XX.htm
